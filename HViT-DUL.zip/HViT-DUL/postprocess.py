import torch
import random
import numpy as np
from torch import nn
import csv
import torch
import os
import torch.nn.functional as F
import matplotlib.pyplot as plt
from sklearn.metrics import roc_auc_score


def fact(x):
    if x == 1 or x == 0:
        return 1
    return x * fact(x - 1)


def Comb(n, m):
    ma = fact(m) * fact(n - m)
    son = fact(n)
    result = son / ma
    return result


def P_value(fpr, tp, nfold, sop=30):   # 30min=0.5h
    p_ = 0
    sop = sop / 60
    P = 1 - np.exp(-fpr * sop)
    for i in range(tp, nfold + 1):
        Q1 = (1 - P) ** (nfold - i)
        Q2 = (P ** i)
        p_ = p_ + Comb(nfold, i) * Q1 * Q2
    return p_


def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True


def write_csv(Probs_hot, target):
    save_path = './cache/'
    pred_labels = Probs_hot.argmax(dim=1)  # Tensor(1900,2)->tensor(1900,) one-hot编码转整数编码
    pred_labels = pred_labels.view(1, -1)  # tensor(1900,)->tensor(1,1900)
    # true_labels = target_hot.argmax(dim=1)
    true_labels = target.view(1, -1)
    head = ['pred_labels', 'true_labels']
    labels = torch.cat((pred_labels, true_labels), dim=0)  # tensor(2, 1900)
    List = labels.cpu().numpy().tolist()  # tensor(2,1900)->nd(2,1900)->list:2
    L = np.transpose(List)  # nd(1900,2)
    if os.path.exists(
            os.path.join(save_path, 'prediction.csv')):  # https://blog.csdn.net/m0_46483236/article/details/109583685
        os.remove(os.path.join(save_path, 'prediction.csv'))
    with open(os.path.join(save_path, 'prediction.csv'), 'a', encoding='utf8', newline='') as f:  # 不自动添加新行
        writer = csv.writer(f)
        writer.writerow(head)
        writer.writerows(L)
    print('test finish')


def MMCD_Pred(model, classifier, data, D=3):
    logits = classifier(model(data))
    n_probs = F.softmax(logits, dim=1)
    n_probs = n_probs.view(-1, D, 2)  # tensor(-1, n_aggrate, n_classes)
    n_probs_mean = torch.mean(n_probs, 1)  # (5580,) tensor(-1, n_classes)
    probs = n_probs_mean.repeat(1, D).view(-1, 2)  # tensor(n_samples, n_classes)
    entropy = - 1.0 * (probs * torch.log(probs + 1e-16)).sum(-1)
    return probs, entropy


def uncertainty(probs):
    means = probs.mean()
    var = (probs - means) ** 2
    return var


def cal_mectric_wo_var(pred_prob, target, numts=10, SOP=30):    # without=wo
    k = 100 / numts
    n = 150 / numts

    prob_scores = pred_prob[:, 1]
    auc = roc_auc_score(target.cpu(), prob_scores.cpu())

    Result_t, Result_f = list(), list()
    boundary = int(SOP * 60 / numts) - 1  # boundary line
    refractory = int(30 * 60 / numts) - 1  # 30-minute refractory period
    acc_t, acc_f, fp, tp, fn, tn, el = 0, 0, 0, 0, 0, 0, 0  # accumulator
    while el < len(pred_prob):
        if el <= boundary:    # 30*60/30
            if pred_prob[el][1] > 0.5:
                acc_t += 1
                Result_t.append(1)
            else:
                Result_t.append(0)

            if len(Result_t) > n:
                acc_t -= Result_t.pop(0)
            if acc_t >= k:  # k/n
                tp += 1
                el = boundary
            el += 1

        else:
            if pred_prob[el][1] > 0.5:  # FP
                acc_f += 1
                Result_f.append(1)
            else:
                Result_f.append(0)
            if len(Result_f) > n:
                acc_f -= Result_f.pop(0)
            if acc_f >= k:
                fp += 1
                acc_f = 0
                Result_f = []
                el += refractory
            el += 1
    print("No. fp：%d , No. tp：%d" % (fp, tp))

    return round(auc, 4), fp, tp


# k-of-n:
def cal_mectric(pred_prob, target, var, tp_u, fp_u, numts=10, SOP=30):
    k = 100 / numts
    n = 150 / numts

    prob_scores = pred_prob[:, 1]
    auc = roc_auc_score(target.cpu(), prob_scores.cpu())

    Result_t, Result_f, Result_tp_u, Result_fp_u = list(), list(), list(), list()  # u-->uncertainty
    boundary = int(SOP * 60 / numts) - 1  # boundary line
    refractory = int(30 * 60 / numts) - 1  # 30-minute refractory period
    acc_t, acc_f, fp, tp, fn, tn, el = 0, 0, 0, 0, 0, 0, 0  # accumulator
    while el < len(pred_prob):
        if el <= boundary:    # 30*60/30
            if pred_prob[el][1] > 0.5:
                acc_t += 1
                Result_t.append(1)
            else:
                Result_t.append(0)
            Result_tp_u.append(var[el].item())
            if len(Result_t) > n:
                acc_t -= Result_t.pop(0)
                Result_tp_u.pop(0)
            if acc_t >= k:
                tp += 1
                tp_u.append(sum(Result_tp_u)/len(Result_tp_u))
                el = boundary
            el += 1

        else:
            if pred_prob[el][1] > 0.5:  # FP
                acc_f += 1
                Result_f.append(1)
            else:
                Result_f.append(0)
            Result_fp_u.append(var[el].item())
            if len(Result_f) > n:
                acc_f -= Result_f.pop(0)
                Result_fp_u.pop(0)
            if acc_f >= k:
                fp += 1
                fp_u.append(sum(Result_fp_u)/len(Result_fp_u))
                acc_f = 0
                Result_f = []
                Result_fp_u = []
                el += refractory
            el += 1
    print("No. fp：%d , No. tp：%d" % (fp, tp))

    return round(auc, 3), fp, tp


def draw_fig(train_losses, train_acces, eval_losses, eval_acces):
    plt.plot(np.arange(len(train_losses)), train_losses, label="train loss")
    plt.plot(np.arange(len(train_acces)), train_acces, label="train acc")
    plt.plot(np.arange(len(eval_losses)), eval_losses, label="valid loss")
    plt.plot(np.arange(len(eval_acces)), eval_acces, label="valid acc")
    plt.legend()
    plt.xlabel('epoches')
    plt.title('Model accuracy&loss')
    plt.show()
