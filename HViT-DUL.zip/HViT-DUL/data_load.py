import torch
import torch.optim
from torch.utils.data import TensorDataset, DataLoader


def build_dataload(x_train, y_train, x_val, y_val, x_test, y_test):
    # convert numpy.ndarrary to tensor
    x_train = torch.from_numpy(x_train).to(torch.float32)   # nd->torch.float32->torch.float32
    x_val = torch.from_numpy(x_val).to(torch.float32)   # 或torch.tensor(x_val).to(torch.float32)
    x_test = torch.from_numpy(x_test).to(torch.float32)

    y_train = torch.LongTensor(y_train)  # nd->torch.int64 (11124,)
    y_val = torch.LongTensor(y_val)
    y_test = torch.LongTensor(y_test)

    train_dataset = TensorDataset(x_train, y_train)
    val_dataset = TensorDataset(x_val, y_val)
    test_dataset = TensorDataset(x_test, y_test)

    # dataloader
    train_dataloader = DataLoader(train_dataset, batch_size=128, drop_last=True, shuffle=True)   # 64 shuffle=True
    val_dataloader = DataLoader(val_dataset, batch_size=128, drop_last=False)
    test_dataloader = DataLoader(test_dataset, batch_size=60, drop_last=False)

    return train_dataloader, val_dataloader, test_dataloader
