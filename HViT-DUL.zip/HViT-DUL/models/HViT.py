import torch
import torch.nn as nn
from torch.nn import init
from utils.config import config_my
from torch import cosine_similarity
import torch.nn.functional as F


class Flatten(nn.Module):
    def forward(self, inputs):
        return inputs.view(inputs.size(0), -1)


class LayerNorm(nn.Module):
    r""" LayerNorm that supports two data formats: channels_last (default) or channels_first.
    The ordering of the dimensions in the inputs. channels_last corresponds to inputs with
    shape (batch_size, height, width, channels) while channels_first corresponds to inputs
    with shape (batch_size, channels, height, width).
    """

    def __init__(self, normalized_shape, eps=1e-6, data_format="channels_first"):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.bias = nn.Parameter(torch.zeros(normalized_shape))
        self.eps = eps
        self.data_format = data_format
        if self.data_format not in ["channels_last", "channels_first"]:
            raise NotImplementedError
        self.normalized_shape = (normalized_shape,)

    def forward(self, x):
        if self.data_format == "channels_last":
            return F.layer_norm(x, self.normalized_shape, self.weight, self.bias, self.eps)
        elif self.data_format == "channels_first":
            u = x.mean(1, keepdim=True)
            s = (x - u).pow(2).mean(1, keepdim=True)
            x = (x - u) / torch.sqrt(s + self.eps)
            x = self.weight[:, None, None] * x + self.bias[:, None, None]
            return x


class PatchEmbed(nn.Module):
    def __init__(self, args, in_c=1):
        super().__init__()

        self.proj1 = nn.Conv2d(in_c, 10, kernel_size=(17, 1), stride=(10, 1), padding=(8, 0))
        self.norm1 = LayerNorm(10, eps=1e-6, data_format="channels_first")
        self.relu = nn.ReLU(inplace=True)
        self.proj2 = nn.Conv2d(in_c, 6, kernel_size=(3, 1), stride=(1, 1), padding=(1, 0))
        self.pool = nn.MaxPool2d((10, 1))
        if args.dataset == 'Kaggle':
            self.norm = nn.BatchNorm2d(6)   # for Kaggle
        else:
            self.norm = LayerNorm(6, eps=1e-6, data_format="channels_first")    # for CHB-MIT

    def forward(self, x):   # (b, 1, t, n)
        x1 = self.relu(self.norm1(self.proj1(x)))
        x2 = self.pool(self.relu(self.proj2(x)))
        x2 = self.norm(x2)
        return torch.cat((x1, x2), dim=1)   # (b, 16, 128, c)


class Attention(nn.Module):
    def __init__(self, embed_dim, num_heads=1, bias=True):  # 128 2 12 0
        super(Attention, self).__init__()
        self.num_heads = num_heads
        self.head_dim = embed_dim // num_heads
        self.to_qkv = nn.Conv2d(embed_dim, 2 * embed_dim + num_heads, 1, 1, bias=bias)
        self.attend = nn.Softmax(dim=-1)

        self.to_out = nn.Sequential(
            nn.Conv2d(embed_dim, embed_dim, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1)),  #
            nn.BatchNorm2d(embed_dim),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        b, c, t, n = x.shape  # (b,c,t,n)
        qkv = self.to_qkv(x).reshape(b, self.num_heads, -1, t, n)
        i, k, v = torch.split(
            qkv, split_size_or_sections=[1, self.head_dim, self.head_dim], dim=2
        )
        scores = self.attend(i)  # (b, h, 1, t, n)
        attn_vector = k * scores  # (b, h, c//h, t, n)
        attn_vector = torch.sum(attn_vector, dim=-1, keepdim=True)  # (b, h, c//h, t, 1)
        out = (F.relu(v) * attn_vector.expand_as(v)).reshape(b, -1, t, n)  # (b, c, t, n)
        out = self.to_out(out)
        return out


class PreNorm(nn.Module):
    def __init__(self, dim, fn):
        super(PreNorm, self).__init__()
        self.norm = nn.BatchNorm2d(dim)
        self.fn = fn

    def forward(self, x, **kwargs):
        return self.fn(self.norm(x), **kwargs)


class FeedForward(nn.Module):
    def __init__(self, dim, mlp_ratio):
        super(FeedForward, self).__init__()
        self.net = nn.Sequential(
            nn.Conv2d(dim, dim, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1)),  #
            nn.BatchNorm2d(dim),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):   # (64,32,100,7)
        return self.net(x)


class Former(nn.Module):
    def __init__(self, dim, num_heads, mlp_ratio):
        super(Former, self).__init__()
        self.layers = nn.ModuleList([])
        self.layers.append(nn.ModuleList([
            PreNorm(dim, Attention(dim, num_heads)),
            PreNorm(dim, FeedForward(dim, mlp_ratio))
        ]))

    def forward(self, x):  # z=(64,h,d)
        for attn, ff in self.layers:
            x = attn(x) + x
            x = ff(x) + x
        return x


class BaseBlock(nn.Module):
    def __init__(self, inp=16, out=32, ks=3, stride=2, num_heads=1, mlp_ratio=2):
        super(BaseBlock, self).__init__()
        self.mlp_ratio = mlp_ratio
        self.former = Former(dim=out, num_heads=num_heads, mlp_ratio=mlp_ratio)

        self.downsample_layer = nn.Sequential(
            nn.Conv2d(inp, inp*4, ks, stride, padding=ks//2, groups=inp),
            nn.ReLU(inplace=True),
            nn.Conv2d(inp*4, out, 1, 1, 0, bias=False),  # don't need bias
            nn.BatchNorm2d(out),
        )
        self.downsample = nn.Sequential(
            nn.Conv2d(out, out * 2, 3, 1, padding=1, groups=out),
            nn.ReLU(inplace=True),
            nn.Conv2d(out * 2, out, 1, 1, 0, bias=False),  # don't need bias
            nn.BatchNorm2d(out),
        )

    def forward(self, x):
        x = self.downsample_layer(x)
        # x = self.downsample(x)
        x = self.former(x)
        return x


class HViT(nn.Module):
    def __init__(self, args, cfg, inputs_shape):
        super().__init__()
        self.w1 = torch.nn.Parameter(torch.FloatTensor(1), requires_grad=True)
        # initialization
        self.w1.data.fill_(8)

        self.args = args
        self.patchembed = PatchEmbed(args, in_c=1)
        for arg in cfg['C2T1']:
            self.C2Tblock1 = BaseBlock(**arg)
        for arg in cfg['C2T2']:
            self.C2Tblock2 = BaseBlock(**arg)

        self.mu_proj = nn.Sequential(
            nn.Conv2d(32, 32 * 4, 3, 2, padding=1, groups=32),
            nn.ReLU(inplace=True),
            nn.Conv2d(32 * 4, 64, 1, 1, 0, bias=False),  # don't need bias
            nn.BatchNorm2d(64),
            nn.Conv2d(64, 64, kernel_size=(5, 3), stride=(1, 1), padding=(2, 0)),
            nn.BatchNorm2d(64),
            nn.GELU(),
            nn.AdaptiveAvgPool2d((1, 1)),
            Flatten()
        )

        self.sigma_proj = nn.Sequential(
            nn.Conv2d(32, 32 * 4, 3, 2, padding=2, groups=32),
            nn.ReLU(inplace=True),
            nn.Conv2d(32 * 4, 64, 1, 1, 0, bias=False),
            nn.BatchNorm2d(64),
            nn.AdaptiveAvgPool2d((1, 1)),
            Flatten()
        )

        self.init_params()

    def Gauss_reparameterize(self, mu, logvar):  # Gaussian
        std = torch.exp(logvar).sqrt()
        epsilon = torch.randn_like(std)
        return mu + epsilon * std

    def Laplace_reparameterize(self, mu, logb):
        b = torch.exp(logb).clamp(min=1e-8)
        epsilon = torch.randn_like(mu)
        z = torch.rand_like(mu)
        sign = torch.sign(z - 0.5)
        epsilon = sign * epsilon
        epsilon = torch.where(torch.abs(z - 0.5) > 1e-8, epsilon, torch.zeros_like(mu))
        mask = (1 - torch.abs(epsilon)) > 1e-8
        epsilon = torch.where(mask, epsilon, torch.zeros_like(mu))
        z = torch.where(mask, z, torch.zeros_like(mu))
        t = 2.0 * torch.abs(z - 0.5) + 1e-8
        t = torch.where(t < 1, t, torch.full_like(t, 1))
        return mu - b * sign * torch.log1p(-t * epsilon)

    def Gauss_kL_loss(self, mu, logvar):
        kl_loss = -0.5 * (1 + logvar - mu.pow(2) - logvar.exp()).sum(dim=1).mean()
        return kl_loss

    def Laplace_kl_loss(self, mu, logb):
        kl_loss = - (1 + logb - mu.abs() - torch.exp(logb)).sum(dim=1).mean()
        return kl_loss

    def sigma_loss(self, log_sigma):
        sigma = torch.exp(log_sigma)
        avg_sigma = sigma.mean(dim=1, keepdim=True).repeat(1, log_sigma.shape[1])
        sigma_loss = torch.abs(sigma / avg_sigma - 1.0).mean()
        return sigma_loss

    def forward(self, x, target_y, classifier, phase='train'):
        x = self.patchembed(x)  # (128, 16, 128, 22)
        x = self.C2Tblock1(x)
        x = self.C2Tblock2(x)

        if self.args.pred_mode == 'Base':
            features = self.mu_proj(x)  # (128,64)
            logits = classifier(features)   # (128, 2)
            loss = F.cross_entropy(logits, target_y).cuda()
            return logits, loss
        else:
            mu = self.mu_proj(x)  # (128,64,1,1)
            log_sigma = self.sigma_proj(x)

            if phase == 'train':
                rep_features = self.Gauss_reparameterize(mu, log_sigma) if self.args.pred_mode == 'DUL-G' \
                    else self.Laplace_reparameterize(mu, log_sigma)
                rep_logits = classifier(rep_features)
                ce_loss = F.cross_entropy(rep_logits, target_y)
                kl_loss = self.Gauss_kL_loss(mu, log_sigma)if self.args.pred_mode == 'DUL-G' \
                    else self.Laplace_kl_loss(mu, log_sigma)

                loss = (ce_loss * torch.sigmoid(self.w1) + (1 - torch.sigmoid(self.w1)) * kl_loss).cuda()
                # print(f'{torch.sigmoid(self.w1).item()}')
                return rep_logits, loss
            else:
                logits = classifier(mu)
                probs = F.softmax(logits, dim=-1)
                uncertainty = -(probs * torch.log(probs + 1e-16)).sum(-1)
                ce_loss = F.cross_entropy(logits, target_y)

                return logits, ce_loss, uncertainty

    def init_params(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                if m.bias is not None:
                    init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm2d):
                init.constant_(m.weight, 1)
                init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                init.normal_(m.weight, std=0.001)  # 0.001
                if m.bias is not None:
                    init.constant_(m.bias, 0)


class Classifier(nn.Module):
    def __init__(self, feature_size=64):
        super(Classifier, self).__init__()
        self.fc = nn.Sequential(
            nn.Linear(feature_size, 2)
        )

    def forward(self, x):
        return self.fc(x)