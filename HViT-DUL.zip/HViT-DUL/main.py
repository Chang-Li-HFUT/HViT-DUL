import json
import os
import os.path
import time
import torch.optim
import sys
import torchvision
import torch.nn.functional as F
from data_load import build_dataload

from models.HViT import HViT, Classifier
from utils.config import config_my
from postprocess import P_value, write_csv, setup_seed, cal_mectric, cal_mectric_wo_var, draw_fig
from utils.earlystopping import EarlyStopping
from utils.misc import AverageMeter, binary_accuracy
from utils.load_signals import PrepData
from utils.prep_data import train_val_loo_split


def makedirs(dir):
    try:
        os.makedirs(dir)
    except:
        pass


def _report_settings():
    """ Report the settings """
    str_ = '-' * 16
    print('%sEnvironment Versions%s' % (str_, str_))
    print("- Python    : {}".format(sys.version.strip().split('|')[0]))
    print("- PyTorch   : {}".format(torch.__version__))
    print("- TorchVison: {}".format(torchvision.__version__))
    print("- USE_GPU   : {}".format(torch.cuda.is_available()))
    print('-' * 52)


def main(args):
    global total_interictal, nfold
    with open('SETTINGS_%s.json' % args.dataset) as f:
        settings = json.load(f)
    makedirs(str(settings['cachedir']))
    makedirs(str(settings['folderdir']))
    if settings['dataset'] == 'Kaggle':
        targets = [
            # 'Dog_1',
            'Dog_2',
            'Dog_3',
            'Dog_4',
            'Dog_5',
            # 'Patient_1',
            # 'Patient_2'
        ]
    elif settings['dataset'] == 'FB':
        targets = [
            '1',
            '3',
            '4',
            '5',
            '6',
            '13',
            '14',
            '15',
            '16',
            '17',
            '18',
            '19',
            '20',
            '21'
        ]
    else:   # CHB-MIT
        targets = [
            '1',
            '2',
            '3',
            # '4',
            '5',
            # '6',
            # '7',
            '8',
            '9',
            '10',
            '11',
            # '12',
            '13',
            '14',
            # '15',
            '16',
            '17',
            '18',
            '19',
            '20',
            '21',
            '22',
            '23',
        ]

    tp_u, fp_u = list(), list()
    for target in targets:
        pre_X, pre_y = PrepData(target, type='ictal', settings=settings, window=args.window, SOP=args.SOP).apply()
        inter_X, inter_y = PrepData(target, type='interictal', settings=settings, window=args.window,
                                    SOP=args.SOP).apply()
        loo_folds = train_val_loo_split(pre_X, pre_y, inter_X, inter_y, args.val_ratio)

        AUC_list, TP_list, FP_list = list(), list(), list()
        for index, (X_train, y_train, X_val, y_val, X_test, y_test, nfold, total_interictal) in enumerate(loo_folds):
            train_dataloader, val_dataloader, test_dataloader = \
                build_dataload(X_train, y_train, X_val, y_val, X_test, y_test)

            model = HViT(args, config_my, X_train.shape).cuda()
            model_lr, head_lr, weight_decay = 6e-3, 3e-4, 1e-2
            classifier = Classifier(feature_size=64).cuda()

            optimizer = torch.optim.AdamW([{"params": model.parameters()},
                                           {"params": classifier.parameters(), "lr": head_lr}],  # AdamW 3e-4
                                          lr=model_lr, betas=(0.9, 0.999), eps=1e-08, weight_decay=weight_decay)

            # loss_fn = torch.nn.CrossEntropyLoss()
            early_stopping = EarlyStopping(args.patience, verbose=True)

            for epoch in range(args.epochs):
                model.train()
                classifier.train()
                train_loss, train_acc = AverageMeter(), AverageMeter()
                for data, labels in train_dataloader:
                    data, labels = data.cuda(), labels.cuda()  # Tensor(100,1,2048,22)
                    logits, loss = model(data, labels, classifier, phase='train')

                    optimizer.zero_grad()
                    loss.backward()
                    optimizer.step()

                    train_loss.update(loss.item(), data.size(0))
                    acc = binary_accuracy(logits, labels)
                    train_acc.update(acc, data.size(0))

                model.eval()
                classifier.eval()
                eval_loss, eval_acc = AverageMeter(), AverageMeter()
                with torch.no_grad():
                    for data, label in val_dataloader:
                        data, label = data.cuda(), label.cuda()  # tensor(100,1,2048,22)

                        if args.pred_mode != 'Base':
                            logits, loss, _ = model(data, label, classifier, phase='test')
                        else:
                            logits, loss = model(data, label, classifier, phase='test')

                        eval_loss.update(loss.item(), data.size(0))
                        acc = binary_accuracy(logits, label)
                        eval_acc.update(acc, data.size(0))

                    print('epoch {}/40 train_loss: {:.6f} | val_loss: {:.6f} | train_acc: {:.6f} | val_acc: {:.6f}'
                          .format(epoch + 1, train_loss.avg, eval_loss.avg,
                                  train_acc.avg, eval_acc.avg))

                    early_stopping(eval_loss.avg, model, classifier)
                    if early_stopping.early_stop:
                        break

            model.load_state_dict(torch.load('model.pt'))  # loading weight
            classifier.load_state_dict(torch.load('classifier.pt'))
            model.eval()
            classifier.eval()
            with torch.no_grad():
                k = 0
                for data, label in test_dataloader:
                    data = data.cuda()
                    label = label.cuda()

                    if args.model == 'HViT':
                        if args.pred_mode != 'Base':
                            logits, _ = model(data, label, classifier, phase='test')
                        else:
                            logits, _, uncertainty = model(data, label, classifier, phase='test')
                    else:
                        features = model(data)
                        logits = classifier(features)
                    probs = F.softmax(logits, dim=1)
                    pred = probs if k == 0 else torch.cat((pred, probs), dim=0)
                    true = label if k == 0 else torch.cat((true, label), dim=0)
                    if args.pred_mode != 'Base':
                        var = uncertainty if k == 0 else torch.cat((var, uncertainty), dim=0)
                    k += 1

            auc, fp, tp = cal_mectric(pred, true, var, tp_u, fp_u, numts=args.window, SOP=args.SOP) \
                if args.pred_mode != 'Base' else cal_mectric_wo_var(pred, true, numts=args.window, SOP=args.SOP)
            TP_list.append(tp)
            FP_list.append(fp)
            AUC_list.append(auc)
            print("Each AUC:", auc)

        total_inter_time = (total_interictal * args.window) / (60 * 60)
        print(f'Total inter time:{total_inter_time:.2f} (/h)')
        Sensitivity = sum(TP_list) / nfold
        FPR = sum(FP_list) / total_inter_time
        p = P_value(FPR, sum(TP_list), nfold, sop=args.SOP)  # 30min=0.5h
        AUC_score = sum(AUC_list) / len(AUC_list)
        print(f'Sen:{Sensitivity:.4f}  FPR:{FPR:.4f}  AUC:{AUC_score:.4f}  p_value:{p:.4f}')
        print(f'AUC of Each fold:{AUC_list}')

    if args.pred_mode != 'Base':
        print(f'TP Unceratinty: {tp_u}')
        print(f'FP Unceratinty: {fp_u}')


if __name__ == '__main__':
    setup_seed(43)  # 4 groups for mean =[42,43,44,45]
    import argparse

    os.environ["CUDA_VISIBLE_DEVICES"] = '0'
    _report_settings()

    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", default='CHBMIT', help="FB, CHBMIT or Kaggle")
    parser.add_argument('--window', type=int, default=5, help="second")  # second
    parser.add_argument('--SOP', type=int, default=30, help=" 30 min for CHBMIT and Kaggle", choices=[30, 60])  # 30min
    parser.add_argument('--pred_mode', type=str, default='DUL-G', help="Only for HViT, others default Base",
                        choices=['Base', 'DUL-G', 'DUL-L'])
    parser.add_argument('--val_ratio', type=float, default=0.2, help="20% for val, 80% for train")
    parser.add_argument('--epochs', type=int, default=40, help="num of epoches")
    parser.add_argument('--patience', type=int, default=10, help="patience for earlystopping")

    args = parser.parse_args()

    main(args)
