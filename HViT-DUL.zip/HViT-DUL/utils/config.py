config_my = {
    'name': 'mfmy',
    'kernel': (3, 3),
    'stem': 16,
    'C2T1': [{'inp': 16, 'out': 32, 'ks': 3, 'stride': 2, 'num_heads': 8}],
    'C2T2': [{'inp': 32, 'out': 32, 'ks': 3, 'stride': 1, 'num_heads': 8}],
    'C2T3': [{'inp': 32, 'out': 64, 'ks': 3, 'stride': 2, 'num_heads': 8}],
    'fc2': 2,  # num_clasess
}
config = {
    'mfmy': config_my,
}

