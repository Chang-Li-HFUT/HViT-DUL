import os
import numpy as np
import pandas as pd
import scipy.io
from scipy.signal import resample
from mne.io import read_raw_edf
from utils.save_load import save_hickle_file, load_hickle_file
from utils.group_seizure_Kaggle import group_seizure
# import stft


def load_signals_CHBMIT(data_dir, folderdir, target, data_type, Set_SOP):
    print(f'load_signals_CHBMIT for Patient {target}')
    onset = pd.read_csv(os.path.join(folderdir, 'seizure_summary.csv'), header=0)   # DataFrame(198,3)
    osfilenames, szstart, szstop = onset['File_name'], onset['Seizure_start'], onset['Seizure_stop']    # Series:(198,)
    osfilenames = osfilenames.tolist()  # ictal file list: ['chb18_29.edf',...]

    segment = pd.read_csv(os.path.join(folderdir, 'segmentation.csv'), header=None)  # DataFrame(198,3)
    nsfilenames = segment[segment[1] == 0][0].tolist()  # non-ictal files

    nsdict = dict()
    targets = ['%d' % i for i in range(1, 24)]
    for t in targets:
        nslist = [elem for elem in nsfilenames if
                  any(x in elem for x in [f'chb{int(t):02d}_', f'chb{int(t):02d}a_', f'chb{int(t):02d}b_', f'chb{int(t):02d}c_'])]
        nsdict[t] = nslist

    Patient = f'chb{int(target):02d}'  # 'chb01'
    target_dir = os.path.join(data_dir, Patient)

    if data_type == 'ictal':
        filenames = [f for f in os.listdir(target_dir) if f.endswith('.edf') and f in osfilenames]
    elif data_type == 'interictal':
        filenames = [f for f in os.listdir(target_dir) if f.endswith('.edf') and any(x in f for x in nsdict[target])]

    if target in ['13', '16']:  # 16
        chs = [u'FP1-F7', u'F7-T7', u'T7-P7', u'P7-O1', u'FP1-F3', u'F3-C3', u'C3-P3', u'P3-O1', u'FP2-F4',
               u'F4-C4', u'C4-P4', u'P4-O2', u'FP2-F8', u'F8-T8', u'FZ-CZ', u'CZ-PZ']
    else:  # 22
        chs = [u'FP1-F7', u'F7-T7', u'T7-P7', u'P7-O1', u'FP1-F3', u'F3-C3', u'C3-P3', u'P3-O1', u'FP2-F4', u'F4-C4',
               u'C4-P4', u'P4-O2', u'FP2-F8', u'F8-T8', u'T8-P8', u'P8-O2', u'FZ-CZ', u'CZ-PZ', u'P7-T7', u'T7-FT9',
               u'FT9-FT10', u'FT10-T8']

    for filename in filenames:
        rawEEG = read_raw_edf(os.path.join(target_dir, filename), verbose=0, preload=False)  # True
        rawEEG.pick_channels(chs)  # RawEDF:921600
        tmp = rawEEG.to_data_frame().to_numpy().astype(np.float32)  # DataFrame:(921600,22) float64->float32
        # tmp = mne.filter.filter_data(tmp.T, sfreq=256, l_freq=1, h_freq=30, method='iir').T
        # tmp = butter_bandpass_filter(tmp, 1, 30, 256, order=5)

        if data_type == 'ictal':
            SOP = Set_SOP * 60 * 256
            indices = [ind for ind, x in enumerate(osfilenames) if x == filename]  # get indices
            if len(indices) > 0:
                # print('%d seizures in the file %s' % (len(indices),filename))
                prev_sp = -1e6
                for i in range(len(indices)):
                    st = szstart[indices[i]] * 256 - 1 * 60 * 256  # SPH=1min
                    sp = szstop[indices[i]] * 256  # postictal=10min
                    # print('Seizure %s %d starts at %d stops at %d last sz stop is %d' %
                    #       (filename, i, (st+5*60*256), sp, prev_sp))

                    # last edf file
                    if filename[6] == '_':
                        seq = int(filename[7:9])
                    else:
                        seq = int(filename[6:8])
                    if filename == 'chb02_16+.edf':
                        prevfile = 'chb02_16.edf'
                    else:
                        prefix = filename[:6] if filename[6] == '_' else filename[:5]
                        prevfile = f"{prefix}_{(seq - 1):02d}.edf"

                    # Is it greater than 15min between two seizures under the same file (SOP>=14min+1min SPH)
                    if st - Set_SOP * 60 * 256 > prev_sp:    # 14
                        PREV_SP = prev_sp
                        prev_sp = sp
                        # Whether the epilepsy alert moment is in the same edf file as its previous 30min moment
                        if st - SOP >= 0:
                            if st - SOP >= PREV_SP:
                                data = tmp[st - SOP: st]
                            else:
                                data = tmp[PREV_SP: st]
                        else:  # 30min before Epilepsy alert in the last edf file
                            if i == 0 and os.path.exists(f'{target_dir}/{prevfile}'):
                                rawEEG = read_raw_edf(f'{target_dir}/{prevfile}', verbose=0, preload=True)
                                rawEEG.pick_channels(chs)
                                prevtmp = rawEEG.to_data_frame().to_numpy().astype(np.float32)
                                # prevtmp = butter_bandpass_filter(prevtmp, 1, 30, 256, order=5)

                                prior_sp = szstop[indices[i] - 1] * 256 if prevfile in filenames else 0
                                if len(prevtmp[prior_sp:]) > len(prevtmp[st - SOP:]):
                                    # The alarm moment is in the current edf file, while the previous 30min moment
                                    # is in the previous edf
                                    data = np.concatenate((prevtmp[st - SOP:], tmp[:st])) if st > 0 else prevtmp[st - SOP:st]
                                else:
                                    data = np.concatenate((prevtmp[prior_sp:], tmp[:st])) if st > 0 else prevtmp[prior_sp:st]

                            else:
                                if i == 0 and st > 0:
                                    data = tmp[:st]
                                elif i > 0 and st > 0:
                                    data = tmp[PREV_SP:st]
                                else:
                                    print("WARNING: file %s does not contain useful info" % filename)
                                    continue
                    else:
                        prev_sp = sp
                        continue

                    print('data shape', data.shape)
                    if data.shape[0] >= 14 * 60 * 256:  # 14
                        yield data
                    else:
                        continue
        elif data_type == 'interictal':
            data = tmp
            print('data shape', data.shape)
            yield data


def load_signals_Kaggle(data_dir, target, data_type):
    print('load_signals_Kaggle for Patient', target)

    dir = os.path.join(data_dir, target)
    done = False
    i = 0
    while not done:
        i += 1
        if target == 'Dog_4' and data_type == 'preictal':
            if 18 < i <= 26 or 38 < i <= 43:
                continue
        if i < 10:
            tar = f'000{i}'
        elif i < 100:
            tar = f'00{i}'
        elif i < 1000:
            tar = f'0{i}'
        else:
            tar = f'{i}'

        filename = f"{dir}/{target}_{data_type}_segment_{tar}.mat"
        if os.path.exists(filename):
            data = scipy.io.loadmat(filename)  # {dict:4}
            # discard preictal segments from 66 to 35 min prior to seizure
            if data_type == 'preictal':
                for skey in data.keys():
                    if "_segment_" in skey.lower():
                        mykey = skey
                sequence = data[mykey][0][0][4][0][0]
                if sequence <= 3:
                    print('Skipping %s....' % filename)
                    continue
            yield data
        else:
            if i == 1:
                raise Exception("file %s not found" % filename)
            done = True


def load_signals_FB(data_dir, target, data_type):
    print('load_signals_FB for Patient', target)

    def strcv(i):
        if i < 10:
            return '000' + str(i)
        elif i < 100:
            return '00' + str(i)
        elif i < 1000:
            return '0' + str(i)
        elif i < 10000:
            return str(i)

    if int(target) < 10:
        Patient = '00' + str(target)
    elif int(target) < 100:
        Patient = '0' + str(target)

    if data_type == 'ictal':

        SOP = 30*60*256
        target_ = 'pat%sIktal' % Patient
        dir = os.path.join(data_dir, target_)
        df_sz = pd.read_csv(
            os.path.join(data_dir, 'seizure.csv'),index_col=None,header=0)
        df_sz = df_sz[df_sz.patient == int(target)]
        df_sz.reset_index(inplace=True, drop=True)

        print(df_sz)
        print('Patient %s has %d seizures' % (target,df_sz.shape[0]))
        for i in range(df_sz.shape[0]):
            data = []
            filename = df_sz.iloc[i]['filename']
            st = df_sz.iloc[i]['start'] - 5*60*256
            print('Seizure %s starts at %d' % (filename, st))
            for ch in range(1, 7):
                filename2 = '%s/%s_%d.asc' % (dir, filename, ch)
                if os.path.exists(filename2):
                    tmp = np.loadtxt(filename2)
                    seq = int(filename[-4:])
                    prevfile = '%s/%s%s_%d.asc' % (dir, filename[:-4], strcv(seq - 1), ch)

                    if st - SOP >= 0:
                        tmp = tmp[st - SOP:st]
                    else:
                        prevtmp = np.loadtxt(prevfile)
                        if os.path.exists(prevfile):
                            if st > 0:
                                tmp = np.concatenate((prevtmp[st - SOP:], tmp[:st]))
                            else:
                                tmp = prevtmp[st - SOP:st]
                        else:
                            if st > 0:
                                tmp = tmp[:st]
                            else:
                                raise Exception("file %s does not contain useful info" % filename)

                    tmp = tmp.reshape(1, tmp.shape[0])
                    data.append(tmp)

                else:
                    raise Exception("file %s not found" % filename)
            if len(data) > 0:
                concat = np.concatenate(data)
                print(concat.shape)
                yield concat

    elif data_type == 'interictal':
        target_ = 'pat%sInteriktal' % Patient
        dir = os.path.join(data_dir, target_)
        text_files = [f for f in os.listdir(dir) if f.endswith('.asc')]
        prefixes = [text[:8] for text in text_files]
        prefixes = set(prefixes)
        prefixes = sorted(prefixes)

        totalfiles = len(text_files)
        print(prefixes, totalfiles)

        done = False
        count = 0

        for prefix in prefixes:
            i = 0
            while not done:
                i += 1
                stri = strcv(i)
                data = []
                for ch in range(1, 7):
                    filename = '%s/%s_%s_%d.asc' % (dir, prefix, stri, ch)

                    if os.path.exists(filename):
                        try:
                            tmp = np.loadtxt(filename)
                            tmp = tmp.reshape(1, tmp.shape[0])
                            data.append(tmp)
                            count += 1
                        except:
                            print('OOOPS, this file can not be loaded', filename)
                    elif count >= totalfiles:
                        done = True
                    elif count < totalfiles:
                        break
                    else:
                        raise Exception("file %s not found" % filename)

                if i > 99999:
                    break

                if len(data) > 0:
                    yield np.concatenate(data)


class PrepData:
    def __init__(self, target, type, settings, window, SOP):
        self.target = target
        self.settings = settings
        self.type = type
        self.window = window
        self.SOP = SOP

    def read_raw_signal(self):
        if self.settings['dataset'] == 'CHBMIT':
            self.samp_freq = 256
            self.freq = 256
            return load_signals_CHBMIT(self.settings['datadir'], self.settings['folderdir'], self.target, self.type, self.SOP)
        elif self.settings['dataset'] == 'Kaggle':
            if self.type == 'ictal':
                data_type = 'preictal'
            else:
                data_type = self.type
            return load_signals_Kaggle(self.settings['datadir'], self.target, data_type)
        elif self.settings['dataset'] == 'FB':
            self.samp_freq = 256
            self.freq = 256
            return load_signals_FB(self.settings['datadir'], self.target, self.type)

        return None

    def preprocess_MIT(self, data_):
        ictal = self.type == 'ictal'
        targetFrequency = self.freq  # re-sample to target frequency
        numts = self.window  # 15s

        df_sampling = pd.read_csv(
            'sampling_%s.csv' % self.settings['dataset'],
            header=0, index_col=None)
        trg = int(self.target)

        ictal_ovl_pt = \
            df_sampling[df_sampling.Subject == trg].ictal_ovl.values[0]
        ictal_ovl_len = int(targetFrequency * ictal_ovl_pt * numts)

        def process_raw_data(mat_data):
            print('Loading data...')
            X, y = [], []

            for data in mat_data:
                if self.settings['dataset'] == 'FB':
                    data = data.transpose()

                y_value = 1 if ictal else 0

                X_temp, y_temp = [], []
                total_sample = int(data.shape[0] / targetFrequency / numts) + 1
                window_len = int(targetFrequency * numts)

                for i in range(total_sample):
                    if (i + 1) * window_len <= data.shape[0]:
                        s = data[i * window_len:(i + 1) * window_len, :]  # (256*10, 22)
                        input_data = s.reshape(-1, 1, s.shape[0], s.shape[1])  # (1,1,256*8, 22)

                        X_temp.append(input_data)
                        y_temp.append(y_value)

                # oversampling preictal signals
                if ictal:
                    i = 1
                    while (window_len + (i + 1) * ictal_ovl_len) <= data.shape[0]:
                        s_ = data[i * ictal_ovl_len:i * ictal_ovl_len + window_len, :]  # (256*10, 22)
                        input_data_ = s_.reshape(-1, 1, s_.shape[0], s_.shape[1])

                        X_temp.append(input_data_)
                        y_temp.append(2)
                        i += 1

                X_temp = np.concatenate(X_temp, axis=0)  # list;1954-->nd(1954,1,3840,22)
                y_temp = np.array(y_temp)
                X.append(X_temp)
                y.append(y_temp)

            return X, y

        data = process_raw_data(data_)  # tuple:2

        return data

    def preprocess_Kaggle(self, data_):
        ictal = self.type == 'ictal'
        interictal = self.type == 'interictal'
        if 'Dog_' in self.target:
            targetFrequency = 200   # re-sample to target frequency
            DataSampleSize = targetFrequency
            numts = self.window
        else:
            targetFrequency = 1000
            DataSampleSize = int(targetFrequency/5)
            numts = 60
        sampleSizeinSecond = 600    # 10min X 60s

        df_sampling = pd.read_csv(
            'sampling_%s.csv' % self.settings['dataset'],
            header=0, index_col=None)
        trg = self.target
        # print(df_sampling)
        # print(df_sampling[df_sampling.Subject == trg].ictal_ovl.values)
        ictal_ovl_pt = \
            df_sampling[df_sampling.Subject == trg].ictal_ovl.values[0]
        ictal_ovl_len = int(targetFrequency*ictal_ovl_pt*numts)

        def process_raw_data(mat_data):
            print('Loading data')
            X = []
            y = []
            sequences = []

            for segment in mat_data:
                for skey in segment.keys():
                    if "_segment_" in skey.lower():
                        mykey = skey
                if ictal:
                    y_value = 1
                    sequence = segment[mykey][0][0][4][0][0]
                else:
                    y_value = 0

                data = segment[mykey][0][0][0]   # (16,239766)
                sampleFrequency = segment[mykey][0][0][2][0][0]  # 400HZ

                if sampleFrequency > targetFrequency:   # resample to target frequency
                    # float64-->float32 save cpu memory
                    data = resample(data, targetFrequency*sampleSizeinSecond, axis=-1).astype(np.float32)
                data = data.transpose()  # (16,120000)-->(120000,16)
                data = np.pad(data, (0, 16 - data.shape[-1])) if data.shape[-1] < 16 else data

                total_sample = int(data.shape[0]/DataSampleSize/numts) + 1
                window_len = int(DataSampleSize*numts)

                for i in range(total_sample):

                    if (i+1)*window_len <= data.shape[0]:
                        s = data[i*window_len:(i+1)*window_len, :]  # nd(200*8, 16)
                        input_data = s.reshape(-1, 1, s.shape[0], s.shape[1])  # (1,1,200*8,16)

                        X.append(input_data)
                        y.append(y_value)
                        if ictal:
                            sequences.append(sequence)

                if ictal:
                    # overlapped window
                    i = 1
                    while (window_len + (i + 1)*ictal_ovl_len) <= data.shape[0]:
                        s_ = data[i*ictal_ovl_len:i*ictal_ovl_len + window_len, :]
                        input_data_ = s_.reshape(-1, 1, s_.shape[0], s_.shape[1])

                        X.append(input_data_)
                        y.append(2)
                        sequences.append(sequence)
                        i += 1

            if ictal:
                assert len(X) == len(y)
                assert len(X) == len(sequences)
                X, y = group_seizure(X, y, sequences)
                return X, y
            elif interictal:
                X = np.concatenate(X)
                y = np.array(y)
                return X, y
            else:
                X = np.concatenate(X)
                return X, None

        data = process_raw_data(data_)
        return data

    def apply(self):
        filename = '%s_%s' % (self.type, self.target)   # ictal_Dog_2
        cache = load_hickle_file(
            os.path.join(self.settings['cachedir'], filename))
        if cache is not None:
            return cache

        data = self.read_raw_signal()
        if self.settings['dataset'] == 'Kaggle':
            X, y = self.preprocess_Kaggle(data)
        else:
            X, y = self.preprocess_MIT(data)
        save_hickle_file(
            os.path.join(self.settings['cachedir'], filename),
            [X, y])
        return X, y
