import torch
from torch import nn, einsum
from torch.nn import functional as F


class LayerNorm(nn.Module):
    r""" LayerNorm that supports two data formats: channels_last (default) or channels_first.
    The ordering of the dimensions in the inputs. channels_last corresponds to inputs with
    shape (batch_size, height, width, channels) while channels_first corresponds to inputs
    with shape (batch_size, channels, height, width).
    """

    def __init__(self, normalized_shape, eps=1e-6, data_format="channels_first"):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.bias = nn.Parameter(torch.zeros(normalized_shape))
        self.eps = eps
        self.data_format = data_format
        if self.data_format not in ["channels_last", "channels_first"]:
            raise NotImplementedError
        self.normalized_shape = (normalized_shape,)

    def forward(self, x):
        if self.data_format == "channels_last":
            return F.layer_norm(x, self.normalized_shape, self.weight, self.bias, self.eps)
        elif self.data_format == "channels_first":
            u = x.mean(1, keepdim=True)
            s = (x - u).pow(2).mean(1, keepdim=True)
            x = (x - u) / torch.sqrt(s + self.eps)
            x = self.weight[:, None, None] * x + self.bias[:, None, None]
            return x


class Attention(nn.Module):
    def __init__(self, dim, heads, dropout=0):  # 128 2 12 0
        super(Attention, self).__init__()
        hid_dim = dim * heads  # 1/2*inp
        self.heads = heads
        self.to_q = nn.Conv2d(dim, 1, 1, 1)
        # self.to_q = nn.Conv2d(dim, hid_dim, 1, padding=0, bias=True)  # 16->2*64
        self.to_k = nn.Conv2d(dim, hid_dim, 1, 1)
        self.to_v = nn.Conv2d(dim, hid_dim, 1, 1)

        self.attn_dropout = nn.Dropout(p=dropout)
        self.attend = nn.Softmax(dim=-1)
        self.scale = dim ** -0.5
        self.to_out = nn.Sequential(
            nn.Conv2d(hid_dim, dim, 1, 1, bias=False),
            nn.BatchNorm2d(dim),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        b, c, h, w = x.shape  # x=tensor(b,c,h,w)
        i = self.to_q(x).view(b, 1, -1)    # (b,1,h,w)
        k = self.to_k(x).view(b, self.heads*c, -1)    # (b,2c,h,w)
        v = self.to_v(x).view(b, self.heads*c, -1)    # (b,2c,h,w)
        scores = self.attend(i)  # (b,1,h,w) self.attend(i) (b,1,l)
        scores = self.attn_dropout(scores)
        attn_vector = k * scores  # (b,2c,h,w)
        attn_vector = torch.sum(attn_vector, dim=-1, keepdim=True)  # (b,2c,h,1) -1
        out = (F.relu(v) * attn_vector.expand_as(v)).view(b, self.heads*c, h, -1)  # (b,2c,h,w)
        out = self.to_out(out)

        return x + out  # (b,c,h,w)


class PreNorm(nn.Module):
    def __init__(self, dim, fn):
        super(PreNorm, self).__init__()
        self.norm = nn.BatchNorm2d(dim)
        self.fn = fn

    def forward(self, x, **kwargs):
        return self.fn(self.norm(x), **kwargs)


class FeedForward(nn.Module):
    def __init__(self, dim, heads):
        super(FeedForward, self).__init__()
        hidden_dim = dim * heads
        self.net = nn.Sequential(
            nn.Conv2d(dim, hidden_dim, 3, 1, 1, groups=dim),  # 2*dim
            nn.ReLU(inplace=True),
            nn.Conv2d(hidden_dim, dim, 1, 1, 0),
            nn.BatchNorm2d(dim)
        )

    def forward(self, x):   # (64,32,100,7)
        x = x + self.net(x)
        return x


class Former(nn.Module):
    def __init__(self, dim, heads):
        super(Former, self).__init__()
        self.layers = nn.ModuleList([])
        self.layers.append(nn.ModuleList([
            PreNorm(dim, Attention(dim, heads, dropout=0)),
            PreNorm(dim, FeedForward(dim, heads))
        ]))

    def forward(self, x):  # z=(64,h,d)
        for attn, ff in self.layers:
            x = attn(x) + x
            x = ff(x) + x
        return x
